from snips_fun import *

# -----------------------------------------
# Read VScode snips in JSON and make dictionaries
# -----------------------------------------

# yaml_file = '/Users/taravser/Documents/My_papers/PhenoScript_main/PhenoScript/phenospy_package/phenospy/package-data/phs-config.yaml'
# json_iri, json_type, json_lab = make_dicsFromSnips(yaml_file)
def make_dicsFromSnips(yaml_file):
    # -----------------------------------------
    # Read configuration yaml
    # -----------------------------------------

    print(f"{Fore.BLUE}Reading yaml file...{Style.RESET_ALL}")
    with open(yaml_file, 'r') as f_yaml:
        phs_yaml = yaml.safe_load(f_yaml)
    # print(phs_yaml)
    print(f"{Fore.GREEN}Good! File is read!{Style.RESET_ALL}")

    # -----------------------------------------
    # Read JSON snippets
    # -----------------------------------------

    f_path = phs_yaml['snippet-dir']
    f_path = os.path.join(f_path, "phs-snippets.json")
    print(f"{Fore.BLUE}Reading snippets from JSON:{Style.RESET_ALL}", f_path)

    f = open(f_path)
    json_file = json.load(f)
    f.close()
    print(f"{Fore.GREEN}Good! File is read!{Style.RESET_ALL}")

    # for i in json_file:
    #     print(json_file[i]['prefix'])
    # ss= {}
    # ss.update({'ro-bearer_of': 'http://purl.obolibrary.org/obo/RO_0000053'})
    # ss.update({'>>': 'http://purl.obolibrary.org/obo/RO_0000053'})

    # -----------------------------------------
    # Make snippet dictionaries
    # -----------------------------------------

    json_iri = {}       # 'hao-annellus': 'http://purl.obolibrary.org/obo/HAO_0000095'
    json_type = {}      # 'http://purl.obolibrary.org/obo/HAO_0000097': 'C'
    json_lab = {}       # 'http://purl.obolibrary.org/obo/HAO_0000097': 'anteclypeus'
    for i in json_file:
        #print(json_file[i]['label_4_translation'])
        if (json_file[i]['type'] != 'Tmp'):
            lab = json_file[i]['label_4_translation']
            iri = json_file[i]['iri']
            lab_org = json_file[i]['label_original']
            type = json_file[i]['type']
            for la in lab:
                json_iri.update({la: iri})
            json_type.update({iri: type})
            json_lab.update({iri: lab_org})

    print(f"{Fore.GREEN}Good! Dictionaries from JSON snippets are constructed!{Style.RESET_ALL}")
    # json_iri['<']
    # json_iri['bfo-part_of']
    # json_type['http://purl.obolibrary.org/obo/BFO_0000050']
    # json_lab['http://purl.obolibrary.org/obo/BFO_0000050']
    return json_iri, json_type, json_lab
