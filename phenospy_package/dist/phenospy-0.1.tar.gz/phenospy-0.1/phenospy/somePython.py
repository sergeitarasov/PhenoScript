
def poww(x: float, y:float) -> float :
    """
    Get average daily temperature

    Calculate average temperature from multiple measurements

    >>> poww(2,2)
    4

    :param x: first temp int
    :param y: integer
    :return: power of x and
    """
    return x ** y

def poww2(x: float, y:float) -> float :
    return x ** y
