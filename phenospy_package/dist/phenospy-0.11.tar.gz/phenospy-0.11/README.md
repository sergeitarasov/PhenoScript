# Phenospy
 Python package for describing phenotypes and species using ontologies.


 <p align="left">
  <img src="https://raw.githubusercontent.com/sergeitarasov/PhenoScript/main/Phenoscript_logo.png" width="300" title="Phenoscript logo">
</p>  


## Install
```bash
pip install phenospy
```
## Requirements
* Python >=3.6

## Quick start guide

Coming soon.

### Changelog

